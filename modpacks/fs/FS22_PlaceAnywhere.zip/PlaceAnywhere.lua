--
-- Filename: PlaceAnywhere.lua
-- Author: Ian898
-- Date: 30/11/2022
-- version: 1.0.0.0
--

PlaceAnywhere = {}
PlaceAnywhere.active = false

function PlaceAnywhere:onButtonPlaceAnywhere()
    PlaceAnywhere.active = not PlaceAnywhere.active
    self:updateMenuActionTexts()
end
function PlaceAnywhere:registerMenuActionEvents()
    local _, eventId = nil
    _, eventId = self.inputManager:registerActionEvent(InputAction.PLACEANYWHERE, self, self.onButtonPlaceAnywhere, false, true, false, true)

    self.inputManager:setActionEventTextPriority(eventId, GS_PRIO_VERY_LOW)
    self.inputManager:setActionEventTextVisibility(eventId, true)

    self.placeAnywhereButtonEvent = eventId

    table.insert(self.menuEvents, eventId)

    self:updateMenuActionTexts()
end
function PlaceAnywhere:updateMenuActionTexts()
    if PlaceAnywhere.active then
        self.inputManager:setActionEventText(self.placeAnywhereButtonEvent, g_i18n:getText("PLACEANYWHERE_ACTIVE"))
    else
        self.inputManager:setActionEventText(self.placeAnywhereButtonEvent, g_i18n:getText("PLACEANYWHERE_DEACTIVE"))
    end
end

function PlaceAnywhere:getCanBePlacedAt(superFunc, ...)
    if not PlaceAnywhere.active then
        return superFunc(self, ...)
    end
    return true
end
function PlaceAnywhere:isInsidePlacementPlaces(superFunc, ...)
    if not PlaceAnywhere.active then
        return superFunc(self, ...)
    end
    return false
end
function PlaceAnywhere:getHasOverlap(superFunc, ...)
    if not PlaceAnywhere.active then
        return superFunc(self, ...)
    end
	return false
end
function PlaceAnywhere:getHasOverlapWithPlaces(superFunc, ...)
    if not PlaceAnywhere.active then
        return superFunc(self, ...)
    end
    return false
end
function PlaceAnywhere:getHasOverlapWithZones(superFunc, ...)
    if not PlaceAnywhere.active then
        return superFunc(self, ...)
    end
    return false
end

ConstructionScreen.registerMenuActionEvents = Utils.appendedFunction(ConstructionScreen.registerMenuActionEvents, PlaceAnywhere.registerMenuActionEvents)
ConstructionScreen.updateMenuActionTexts = Utils.appendedFunction(ConstructionScreen.updateMenuActionTexts, PlaceAnywhere.updateMenuActionTexts)
if ConstructionScreen.onButtonPlaceAnywhere == nil then
    ConstructionScreen.onButtonPlaceAnywhere = PlaceAnywhere.onButtonPlaceAnywhere
end

Placeable.getCanBePlacedAt = Utils.overwrittenFunction(Placeable.getCanBePlacedAt, PlaceAnywhere.getCanBePlacedAt)
PlacementUtil.isInsidePlacementPlaces = Utils.overwrittenFunction(PlacementUtil.isInsidePlacementPlaces, PlaceAnywhere.isInsidePlacementPlaces)
PlaceablePlacement.getHasOverlap = Utils.overwrittenFunction(PlaceablePlacement.getHasOverlap, PlaceAnywhere.getHasOverlap)
PlaceablePlacement.getHasOverlapWithZones = Utils.overwrittenFunction(PlaceablePlacement.getHasOverlapWithZones, PlaceAnywhere.getHasOverlapWithZones)
PlaceablePlacement.getHasOverlapWithPlaces = Utils.overwrittenFunction(PlaceablePlacement.getHasOverlapWithPlaces, PlaceAnywhere.getHasOverlapWithPlaces)
