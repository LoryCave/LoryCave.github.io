--
-- PlayerStateActivateWorkshop
--
-- @author Rockstar
-- @date 26/05/2021
--

--
-- @fs22 22/11/2021
--


PlayerStateActivateWorkshop = {}
local PlayerStateActivateWorkshop_mt = Class(PlayerStateActivateWorkshop, PlayerStateBase)

function PlayerStateActivateWorkshop:new(player, stateMachine)
	local self = PlayerStateBase.new(player, stateMachine, PlayerStateActivateWorkshop_mt)

	self.foundVehicle = nil
	self.interactText = ""

	self.isDealer = false
	self.isOwnWorkshop = false
	self.isMobileWorkshop = true

	return self
end

function PlayerStateActivateWorkshop:isAvailable()
	self.foundVehicle = nil

	if self.player:getIsInputAllowed() then
		local lastFoundObject = self.player.lastFoundAnyObject

		if lastFoundObject ~= nil then
			local object = g_currentMission:getNodeObject(lastFoundObject)

			if object ~= nil and object.isa ~= nil and object:isa(Vehicle) and g_currentMission.accessHandler:canFarmAccess(self.player.farmId, object) then
				self.foundVehicle = object
				self.interactText = string.format("%s: %s", g_i18n:getText("action_configSellSpecificVehicle"), object:getFullName())

				return true
			end
		end
	end

	self.interactText = ""

	return false
end

function PlayerStateActivateWorkshop:activate()
	PlayerStateActivateWorkshop:superClass().activate(self)

	g_workshopScreen:setSellingPoint(nil, self.isDealer, self.isOwnWorkshop, self.isMobileWorkshop)
	g_workshopScreen:setVehicles({self.foundVehicle})
	g_gui:showGui("WorkshopScreen")

	self:deactivate()
end