--
-- main
--
-- @author Rockstar
-- @date 26/05/2021
--

--
-- @fs22 22/11/2021
--


source(g_currentModDirectory .. "scripts/Player/PlayerStateActivateWorkshop.lua")

local function PlayerStateMachineNew_inj(self, superFunc, player, custom_mt)
	local ret = superFunc(self, player, custom_mt)

	ret.playerStateActivateWorkshop = PlayerStateActivateWorkshop:new(ret.player, ret)
	ret.stateList.activateWorkshop = ret.playerStateActivateWorkshop
	ret.fsmTable.crouch.activateWorkshop = true
	ret.fsmTable.idle.activateWorkshop = true
	ret.fsmTable.activateWorkshop = {
		crouch = true,
		idle = true,
		walk = true,
		run = true
	}

	return ret
end

local function PlayerNew_inj(self, superFunc, isServer, isClient)
	local ret = superFunc(self, isServer, isClient)

	ret.inputInformation.registrationList[InputAction.ACTIVATE_WORKSHOP] = {
		text = "",
		triggerAlways = false,
		triggerDown = true,
		eventId = "",
		textVisibility = true,
		triggerUp = false,
		callback = function(obj)
			if obj.playerStateMachine:isAvailable("activateWorkshop") then
				obj.playerStateMachine:activateState("activateWorkshop")
			end
		end,
		activeType = Player.INPUT_ACTIVE_TYPE.IS_MOVEMENT
	}

	return ret
end

local function PlayerUpdateActionEvents_inj(self)
	local eventActivateWorkshop = self.inputInformation.registrationList[InputAction.ACTIVATE_WORKSHOP]

	if eventActivateWorkshop ~= nil then
		local eventIdActivateWorkshop = eventActivateWorkshop.eventId

		g_inputBinding:setActionEventActive(eventIdActivateWorkshop, false)
		g_inputBinding:setActionEventTextVisibility(eventIdActivateWorkshop, false)

		if not self:hasHandtoolEquipped() then
			if self.playerStateMachine:isAvailable("activateWorkshop") then
				local activateWorkshopState = self.playerStateMachine:getState("activateWorkshop")

				g_inputBinding:setActionEventActive(eventIdActivateWorkshop, true)
				g_inputBinding:setActionEventTextVisibility(eventIdActivateWorkshop, true)
				g_inputBinding:setActionEventText(eventIdActivateWorkshop, activateWorkshopState.interactText)
			end
		end
	end
end

PlayerStateMachine.new = Utils.overwrittenFunction(PlayerStateMachine.new, PlayerStateMachineNew_inj)
Player.new = Utils.overwrittenFunction(Player.new, PlayerNew_inj)
Player.updateActionEvents = Utils.appendedFunction(Player.updateActionEvents, PlayerUpdateActionEvents_inj)