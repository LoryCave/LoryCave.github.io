----------------------------------------------------------------------------------------------------
-- FREE TERRAFORMING AND PAINTING
----------------------------------------------------------------------------------------------------
-- Purpose: Making free the terraforming/painting/foliage in the build mode
-- Author:  coolfarmer
--
-- Copyright (c) 2021
----------------------------------------------------------------------------------------------------

FreeTerraforming = {}; 

function FreeTerraforming:loadMap(name)
	
	-- Make the terraforming/Displacement cost zero (game default: 10)
	Landscaping.SCULPT_BASE_COST_PER_M3 = 0
	
	-- Make the landscaping/painting cost per cubic meter (game default: 1)
    Landscaping.PAINT_BASE_COST_PER_M2 = 0
	
	-- Make the landscaping/painting cost per cubic meter (game default: 0.2)
	Landscaping.PAINT_BASE_COST_PER_M2 = 0
	
end; 

addModEventListener(FreeTerraforming);
